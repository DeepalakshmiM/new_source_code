//
//  SizerView.h
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GithubAuthController.h"

@interface SizerView : UIView

- (id)initWithFrame:(CGRect)frame frameChangeDelegate:(id<FrameChangeDelegate>)_delegate;

@end