//
//  SizerView.m
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import "SizerView.h"

@interface SizerView()
@property(nonatomic, weak) id<FrameChangeDelegate> delegate;
@end

@implementation SizerView

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame frameChangeDelegate:(id<FrameChangeDelegate>)_delegate
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.delegate = _delegate;
    }
    return self;
}

-(void) layoutSubviews
{
    [self.delegate frameChanged:self.frame];
}

@end
