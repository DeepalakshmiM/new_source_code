//
//  GithubAuthenticatorView.h
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GithubAuthController.h"

@interface GithubAuthenticatorView : UIWebView <UIWebViewDelegate>

@property(nonatomic, weak) id<GitAuthDelegate> authDelegate;

@end