//
//  main.m
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
