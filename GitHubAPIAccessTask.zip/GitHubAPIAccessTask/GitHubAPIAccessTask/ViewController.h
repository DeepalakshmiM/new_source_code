//
//  ViewController.h
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

