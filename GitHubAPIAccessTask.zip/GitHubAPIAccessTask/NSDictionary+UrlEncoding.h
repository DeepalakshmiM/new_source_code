//
//  NSDictionary+UrlEncoding.h
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface NSDictionary (UrlEncoding)

-(NSString*) urlEncodedString;

@end
