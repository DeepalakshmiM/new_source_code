//
//  Defines.h
//  GitHubAPIAccessTask
//
//  Created by Mac on 7/8/16.
//  Copyright © 2016 Seek Innovative Technologies. All rights reserved.
//

#ifndef Defines_h
#define Defines_h

typedef void (^BMBlockVoid)(void);

static NSString *const GITHUB_CALLBACK_URL  = @"https://github.com/login/oauth/authorize";
static NSString *const GITHUB_CLIENT_ID     = @"eaaf031c74abd088cc5d";
static NSString *const GITHUB_CLIENT_SECRET = @"b470556a144f20c82878a89a506f869905d64a6f";

#endif /* Defines_h */
